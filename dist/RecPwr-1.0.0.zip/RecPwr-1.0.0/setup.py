import setuptools
from distutils.core import setup

setup(
    # Application name:
    name="RecPwr",

    # Version number (initial):
    version="1.0.0",

    # Application author details:
    author="Eric Haberland",
    author_email="ehaberland@lightningpacks.com",

    # Packages
    packages=["RecPwr"],

    # Include additional files into the package
    include_package_data=True,

    # Details
    url="https://github.com/haberlae/power_tester/tarball/1.0.0",

    #
    license="LICENSE.txt",
    description="MIT license",

    # long_description=open("README.txt").read(),

    # Dependent packages (distributions)
    install_requires=[
        "PyAutoIt", 
        "easygui",
        "openpyxl",
        "matplotlib",
        "NumPy", 
        
    ],
)